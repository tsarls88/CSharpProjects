﻿using Microsoft.AspNetCore.Mvc;
using WebApp.DAL;
using WebApp.Models;

namespace WebApp.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly Employee_DAL _dal;

        public EmployeeController(Employee_DAL dal)
        {
            _dal = dal;
        }
        [HttpGet]
        public IActionResult Index()
        {

            List<Employees> employees = new List<Employees>();
            try
            {
                employees = _dal.GetAll();
            }
            catch (Exception ex)
            {
                TempData["ErrorMessage"] = ex.Message;

            }
            return View(employees);
        }
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Employees model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    TempData["Error Message"] = "Model Data is Invalid";
                }
                bool result = _dal.Insert(model);
                if (!result)
                {
                    TempData["Error Message"] = "Unable to save the data";
                    return View();
                }
                TempData["Success Message"] = "Employee Details Saved Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error Message"] = ex.Message;
                return View();
            }

        }
        [HttpGet]
        public IActionResult Edit(int Id)
        {
          
            var employee = _dal.GetById(Id);
            return employee == null ? NotFound() : View(employee);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(Employees model, int employee_id)
        {
            try
            {
                if (!ModelState.IsValid)
            {
                TempData["Error"] = "Please Fix Error";
                return View(model);
            }
                bool result = _dal.Update(model);
                if (!result)
                {
                    TempData["Error"] = "Update Failed - Employee Might Does Not exit!";
                    return View(model);
                }
                TempData["Success"] = "Employee Updated Successfully!";
                return RedirectToAction("Index");
            }
            catch (Exception)
            {
                TempData["Error"] = "Employee Updated Successfully!";
                return View(model);
            }

        }
        [HttpGet]
        public IActionResult Delete(int Id)
        {
            try
            {
                var employees = _dal.GetById(Id);
                if (employees == null)
                {
                    TempData["Error Message"] = $"Employee Not Found : {Id}";
                    return RedirectToAction("Index");
                }
                return View(employees);
            }
            catch (Exception ex)
            {
                TempData["Error Message"] = ex.Message;
                return RedirectToAction("Index");
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed (Employees model)
        {
            try
            {
               
                bool result = _dal.Delete(model.employee_Id);
                if (!result)
                {
                    TempData["Error Message"] = "Delete Failed - Unable to Delete the Data";
                    return RedirectToAction("Index");
                }
                TempData["Success Message"] = "Employee Delete Saved Successfully";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
                TempData["Error Message"] = ex.Message;
                return RedirectToAction("Index");
            }

        }

    }
}
