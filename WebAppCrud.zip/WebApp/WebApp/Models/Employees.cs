﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebApp.Models
{
    public class Employees
    {
        [Key]
        public int employee_Id { get; set; }

        [DisplayName("First Name")]
        [Required]
        public string first_name { get; set; }

        [DisplayName("Last Name")]
        [Required]
        public string last_name { get; set; }

        [DisplayName("Age")]
        [Required]
        public int age { get; set; }

        [NotMapped]
        public string FullName
        {
            get
            {
                return first_name + " " + last_name;
            }
        }
    }
}
