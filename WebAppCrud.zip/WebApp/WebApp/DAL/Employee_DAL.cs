﻿// DATA ACCESS LAYER TO CONNECT DATABSE 


using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.Data;
using WebApp.Models;

namespace WebApp.DAL
{
    public class Employee_DAL
    {
        SqlConnection? _connection = null;
        SqlCommand? _command = null;

        public static IConfiguration Configuration { get; set; }

        private string GetConnectionString()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            Configuration = builder.Build();
            return Configuration.GetConnectionString("DefaultConnection");
        }
        public List<Employees> GetAll()
        {
            List<Employees> employeeslist = new List<Employees>();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Get_Employees]";
                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();

                while (dr.Read())
                {
                    Employees employees = new Employees();
                    employees.employee_Id = Convert.ToInt32(dr["employee_Id"]);
                    employees.first_name = dr["first_name"].ToString();
                    employees.last_name = dr["last_name"].ToString();
                    employees.age = Convert.ToInt32(dr["age"]);
                    employeeslist.Add(employees);
                }
                _connection.Close();
            }
            return employeeslist;
        }
        public bool Insert(Employees model)
        {
            int id = 0;
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Insert_Employees]";
                _command.Parameters.AddWithValue("@first_name", model.first_name);
                _command.Parameters.AddWithValue("@last_name", model.last_name);
                _command.Parameters.AddWithValue("@Age", model.age);
                _connection.Open();
                id = _command.ExecuteNonQuery();
                _connection.Close();


            }
            return id > 0 ? true : false;
        }
        public Employees GetById(int id)
        {
            Employees employee = new Employees();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Get_EmployeesByemployee_Id]";
                _command.Parameters.AddWithValue("@employee_Id", id);
                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();

                while (dr.Read())
                {

                    employee.employee_Id = Convert.ToInt32(dr["employee_Id"]);
                    employee.first_name = dr["first_name"].ToString();
                    employee.last_name = dr["last_name"].ToString();
                    employee.age = Convert.ToInt32(dr["age"]);

                }
                _connection.Close();
            }
            return employee;
        }
        public bool Update (Employees model)
        {
            int id = 0;
            using (_connection = new SqlConnection(GetConnectionString()))
            {   
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Update_Employees]";
                _command.Parameters.AddWithValue("@employee_Id", model.employee_Id);
                _command.Parameters.AddWithValue("@first_name", model.first_name);
                _command.Parameters.AddWithValue("@last_name", model.last_name);
                _command.Parameters.AddWithValue("@Age", model.age);
                _connection.Open();
                id = _command.ExecuteNonQuery();
                _connection.Close();


            }
            return id > 0 ? true : false;
        }

        public bool Delete (int id)
        {

            int DeleteRow = 0;
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Delete_Employees]";
                _command.Parameters.AddWithValue("@employee_Id", id);
                _connection.Open();
                DeleteRow = _command.ExecuteNonQuery();
                _connection.Close();


            }
            return DeleteRow > 0 ? true : false;
        }
    }
   
  
}
