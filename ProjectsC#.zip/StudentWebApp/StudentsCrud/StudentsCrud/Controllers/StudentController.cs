﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Routing.Constraints;
using StudentsCrud.DAL;
using StudentsCrud.Models;
using System.Linq.Expressions;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.ExceptionServices;

namespace StudentsCrud.Controllers
{
    public class StudentController : Controller
    {
        private readonly Students_DAL _dal;
        
        public StudentController(Students_DAL dal)
        {
            _dal = dal;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<Students> students = new List<Students>();
            try
            {
                students = _dal.GetAll();
            }
            catch (Exception ex) {
                TempData["Error Message"] = ex.Message;
            }
            return View(students);

        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Students model)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    TempData["Error Message"] = "Model Data is Invalid";
                    
                }
                bool result = _dal.Insert(model);
                if (!result) {
                    TempData["Error Message"] = "Unable to Save Data";
                    return View();
                }
                TempData["Success Message"] = "Employee Details Saved!";
                return RedirectToAction("Index");

            }
            catch (Exception ex) {
                TempData["Error Message"] = ex.Message;
                return View();
            }
        }
        [HttpGet]
        public IActionResult Delete(int id)
        {
            try
            {
                var students = _dal.GetById(id);
                if (students == null)
                {
                    TempData["Error Message"] = $"Students Not Found : {id}";
                    return RedirectToAction("Index");
                }
                return View(students);
            }
            catch (Exception ex)
            {
                TempData["Error Message"] = ex.Message;
                return RedirectToAction("Index");

            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        [ActionName("Delete")]
        public IActionResult DeleteConfirmed(Students model)
        {
            try
            {
                bool result = _dal.Delete(model.student_Id);
                if (!result)
                {
                    TempData["Error Message"] = "Delete Failed!";
                    return RedirectToAction("Index");
                }
                TempData["Success Message!"] = "Student Data Deleted";
                return RedirectToAction("Index");
            }
            catch (Exception ex){
                TempData["Error Message"] = ex.Message ;

            return RedirectToAction("Index");
            }
        }
        [HttpGet]
        public IActionResult Update (int id) {
            var students = _dal.GetById(id);
            return students == null ? NotFound() : View(students);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]

        public IActionResult Update(Students students, int student_Id)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    TempData["Error Message"] = "Please Fix the Error";
                    return View(students);
                }
                bool result = _dal.Update(students);
                if (!result)
                {
                    TempData["Error"] = "Update Failed - Students Does Not Exit.";
                    return View(students);
                }
                TempData["Success Message"] = "Students Updated!";
                return RedirectToAction("Index");
            }
            catch ( Exception ex)
            {
                TempData["Eror"] = ex.Message;
                return View(students);
            }
        }
    }
}
