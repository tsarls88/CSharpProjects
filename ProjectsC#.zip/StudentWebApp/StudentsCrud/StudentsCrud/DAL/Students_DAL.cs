﻿using System.Data;
using Microsoft.Data.SqlClient;
using StudentsCrud.Models;

namespace StudentsCrud.DAL
{
    public class Students_DAL
    {
            SqlConnection? _connection = null;
            SqlCommand? _command = null; 
        
            public static IConfiguration Configuration { get; set; }
            
        private string GetConnectionString()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);

            Configuration = builder.Build();
            return Configuration.GetConnectionString("DefaultConnection");

        }
        public List<Students> GetAll()
        {
            List<Students> studentslist = new List<Students>();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_GET_StudentsTable]";
                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();
                while (dr.Read())
                {
                    Students students = new Students();
                    students.student_Id = Convert.ToInt32(dr["student_Id"]);
                    students.FirstName = dr["FirstName"].ToString();
                    students.LastName = dr["LastName"].ToString();
                    students.Age = Convert.ToInt32(dr["Age"]);
                    students.Course = dr["Course"].ToString();
                    studentslist.Add(students);
                }
                _connection.Close();

            }
            return studentslist;
         
        }
        public bool Insert(Students model)
        {
            int id = 0;
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Insert_StudentsTable]";
                _command.Parameters.AddWithValue("@FirstName", model.FirstName);
                _command.Parameters.AddWithValue("@LastName", model.LastName);
                _command.Parameters.AddWithValue("@Age", model.Age);
                _command.Parameters.AddWithValue("@Course", model.Course);
                _connection.Open();
                id = _command.ExecuteNonQuery();
                _connection.Close();
            }
            return id > 0 ? true : false;
        }

        public Students GetById(int id)
        {
            Students students = new Students();
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_GET_StudentsTableBystudent_Id]";
                _command.Parameters.AddWithValue("@student_Id", id);
                _connection.Open();
                SqlDataReader dr = _command.ExecuteReader();
                while (dr.Read())
                {

                    students.student_Id = Convert.ToInt32(dr["student_Id"]);
                    students.FirstName = dr["FirstName"].ToString();
                    students.LastName = dr["LastName"].ToString();
                    students.Age = Convert.ToInt32(dr["Age"]);
                    students.Course = dr["Course"].ToString();

                }
                _connection.Close();

            }
            return students;
        }
        public bool Delete (int id)
        {
            int DeleteRow = 0;
            using (_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Delete_StudentsTable]";
                _command.Parameters.AddWithValue("@student_Id", id);
                _connection.Open();
                DeleteRow = _command.ExecuteNonQuery(); 
                _connection.Close();
            }
            return DeleteRow > 0 ? true : false;
        }
        public bool Update (Students model)
        {
            int id = 0;
            using(_connection = new SqlConnection(GetConnectionString()))
            {
                _command = _connection.CreateCommand();
                _command.CommandType = CommandType.StoredProcedure;
                _command.CommandText = "[DBO].[usp_Update_StudentsTable]";
                _command.Parameters.AddWithValue("@student_Id", model.student_Id ) ;
                _command.Parameters.AddWithValue("@FirstName", model.FirstName);
                _command.Parameters.AddWithValue("@LastName", model.LastName);
                _command.Parameters.AddWithValue("@Age", model.Age);
                _command.Parameters.AddWithValue("@Course", model.Course);
                _connection.Open();
                id = _command.ExecuteNonQuery();
                _connection.Close();
            }
            return id > 0 ? true : false;
        }

    }
}
